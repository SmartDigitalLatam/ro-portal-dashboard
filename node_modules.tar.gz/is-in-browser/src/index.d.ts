declare const isInBrowser: boolean;
export default isInBrowser;
