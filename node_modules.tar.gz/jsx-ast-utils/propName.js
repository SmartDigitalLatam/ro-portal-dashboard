module.exports = require('./lib').propName; // eslint-disable-line import/no-unresolved
